import java.lang.*;
import java.util.*;
import Classes.*;




public class Home
{
  
    public static void main(String[] args) //throws Exception
    {
        try
        {   
            HomeMenu hm = new HomeMenu();
            hm.homemenu();
            
        }
        catch(Exception e)
        {

        }

    }
}
