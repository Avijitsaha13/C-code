package Interfaces;
import java.lang.*;
import Classes.*;
public interface IBookFileReadWriteDemo 
{
	
	public void showAllBooks();
	public  void purchase(String cred, String uname);
	public void showHistory();



}