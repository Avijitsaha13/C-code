package Interfaces;
import java.lang.*;
import Classes.*;
public interface IMenu 
{
	
	public void menu(String username, String password);


}