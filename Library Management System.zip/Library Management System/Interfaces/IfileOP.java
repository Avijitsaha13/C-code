package Interfaces;
import java.lang.*;
import Classes.*;
public interface IfileOP 
{
	
	
	public void writeInFile(String s, String loc);
	public  void search (String line0);
	public  void verify (String line0);



}