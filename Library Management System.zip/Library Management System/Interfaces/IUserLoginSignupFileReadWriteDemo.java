package Interfaces;
import java.lang.*;
import Classes.*;
public interface IUserLoginSignupFileReadWriteDemo 
{
	
	public  void info(String loc, String empId);
	public  void pay(String cred, String uid);
	public  void verify (String line0, String line1);
	public void initiateReactify();
	public  void rectify (String name, String otp0);
	public void showAllReaders();
	

}